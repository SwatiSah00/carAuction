function validate() {
  var x = document.forms["registerForm"]["email"].value;
    var password = document.forms["registerForm"]["psw"].value;
    var reppassword = document.forms["registerForm"]["psw"].value;
  var passw = /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{7,15}$/;

  var atpos = x.indexOf("@");
  var dotpos = x.lastIndexOf(".");

  if (atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= x.length) {
    alert("Not a valid e-mail address");
    return false;
  }

  if(password === reppassword){
    alert("Correct Passwords!")
    return true;

  }else {
    alert("Passwords Do Not Match!")
  }

}
